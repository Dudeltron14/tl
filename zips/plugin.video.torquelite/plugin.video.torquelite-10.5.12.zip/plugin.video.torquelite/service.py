import xbmc

from resources.lib.catalog_store import refresh


monitor = xbmc.Monitor()
while not monitor.abortRequested():
    try:
        refresh()
    except Exception as exc:
        xbmc.log("Torque Lite catalog service failed: {}".format(exc), xbmc.LOGERROR)
    if monitor.waitForAbort(300):
        break

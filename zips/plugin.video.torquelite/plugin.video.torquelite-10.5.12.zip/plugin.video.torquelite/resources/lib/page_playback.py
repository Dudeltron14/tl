import html
import json
import re
from urllib.parse import parse_qs, urljoin, urlparse
from urllib.request import Request, urlopen


USER_AGENT = "Mozilla/5.0 (Kodi; Torque Lite)"
HLS_RE = re.compile(r'''https://[^\s"'<>]+?\.m3u8(?:\?[^\s"'<>]*)?''', re.IGNORECASE)
IFRAME_RE = re.compile(r'''<iframe\b[^>]*\bsrc\s*=\s*["']([^"']+)["']''', re.IGNORECASE)
CLAPPR_RE = re.compile(
    r'''new\s+Clappr\.Player\s*\(\s*\{.*?\bsource\s*:\s*["']([^"']+\.m3u8[^"']*)["']''',
    re.IGNORECASE | re.DOTALL,
)
HTML_COMMENT_RE = re.compile(r"<!--.*?-->", re.DOTALL)
ACTIVE_ARRAY_RE = re.compile(r"^[ \t]*const array\s*=\s*(\[[^\r\n]+\])", re.MULTILINE)
LIVE_PAGES = {
    "/formulaplayer1": "Formula 1",
    "/mgpplayer2": "MotoGP",
    "/wsbkplayer1": "WorldSBK",
}
PITSPORT_ID_RE = re.compile(r"^/watch/([0-9a-f-]{36})$")


def _playback(address, page_url):
    origin = "{}://{}".format(urlparse(page_url).scheme, urlparse(page_url).netloc)
    return {
        "type": "hls",
        "address": address,
        "headers": {"Origin": origin, "Referer": page_url, "User-Agent": USER_AGENT},
    }


def _active_hls(source):
    source = HTML_COMMENT_RE.sub("", html.unescape(source).replace("\\/", "/"))
    arrays = ACTIVE_ARRAY_RE.findall(source)
    for array in arrays:
        for address in HLS_RE.findall(array):
            parsed = urlparse(address)
            if parsed.scheme == "https" and parsed.hostname and not parsed.username:
                yield address


def _working_hls(addresses, page_url):
    for address in addresses:
        request = Request(address, headers=_playback(address, page_url)["headers"])
        try:
            with urlopen(request, timeout=10) as response:
                if response.read(4096).lstrip().startswith(b"#EXTM3U"):
                    return _playback(address, page_url)
        except OSError:
            continue
    raise ValueError("live page has no working HTTPS HLS source")


def parse_nontonx(page_url, source):
    if urlparse(page_url).hostname != "replay.nontonx.com":
        raise ValueError("unexpected NontonX page host")
    match = HLS_RE.search(html.unescape(source).replace("\\/", "/"))
    if not match:
        raise ValueError("NontonX page has no HTTPS HLS source")
    return {
        "type": "hls",
        "address": match.group(0),
        "headers": {
            "Origin": "https://replay.nontonx.com",
            "Referer": page_url,
            "User-Agent": USER_AGENT,
        },
    }


def resolve_nontonx(page_url):
    request = Request(page_url, headers={"User-Agent": USER_AGENT})
    with urlopen(request, timeout=20) as response:
        return parse_nontonx(page_url, response.read().decode("utf-8", "replace"))


def parse_nonton_live(page_url, source):
    parsed = urlparse(page_url)
    if parsed.hostname != "esp32.nontonx.com" or parsed.path.rstrip("/") not in LIVE_PAGES:
        raise ValueError("unexpected NontonX live page")
    addresses = list(_active_hls(source))
    if not addresses:
        raise ValueError("NontonX live page has no active HTTPS HLS source")
    return addresses


def resolve_nonton_live(page_url):
    request = Request(page_url, headers={"User-Agent": USER_AGENT})
    with urlopen(request, timeout=20) as response:
        addresses = parse_nonton_live(page_url, response.read().decode("utf-8", "replace"))
    return _working_hls(addresses, page_url)


def parse_aces_live(page_url, source):
    parsed = urlparse(page_url)
    if parsed.hostname != "acestrlms.pages.dev" or parsed.path == "/":
        raise ValueError("unexpected Aces live page")
    addresses = list(_active_hls(source))
    if not addresses:
        cleaned = HTML_COMMENT_RE.sub("", html.unescape(source).replace("\\/", "/"))
        addresses = HLS_RE.findall(cleaned)
    if not addresses:
        raise ValueError("Aces live page has no HTTPS HLS source")
    return addresses


def resolve_aces_live(page_url):
    request = Request(page_url, headers={"User-Agent": USER_AGENT})
    with urlopen(request, timeout=20) as response:
        addresses = parse_aces_live(page_url, response.read().decode("utf-8", "replace"))
    return _working_hls(addresses, page_url)


def parse_pitsport_live(page_url, payload):
    parsed = urlparse(page_url)
    match = PITSPORT_ID_RE.match(parsed.path)
    if parsed.hostname != "pitsport.live" or not match:
        raise ValueError("unexpected PitSport live page")
    data = json.loads(payload)
    if not data.get("success") or not isinstance(data.get("content"), list):
        raise ValueError("PitSport returned an unsupported player")
    addresses = []
    for source in data["content"]:
        value = source.get("iframe", "") if isinstance(source, dict) else ""
        value = html.unescape(value).replace("\\/", "/")
        for values in parse_qs(urlparse(value).query).values():
            for nested in values:
                addresses.extend(HLS_RE.findall(nested))
        if not addresses:
            addresses.extend(HLS_RE.findall(value))
    if not addresses:
        raise ValueError("PitSport event has no public HLS source yet")
    return addresses


def resolve_pitsport_live(page_url):
    parsed = urlparse(page_url)
    match = PITSPORT_ID_RE.match(parsed.path)
    if parsed.hostname != "pitsport.live" or not match:
        raise ValueError("unexpected PitSport live page")
    api_url = "https://api.pitsport.st/v1/stream/{}".format(match.group(1))
    request = Request(api_url, headers={"User-Agent": USER_AGENT, "Referer": page_url})
    with urlopen(request, timeout=20) as response:
        addresses = parse_pitsport_live(page_url, response.read().decode("utf-8", "replace"))
    return _working_hls(addresses, page_url)


def parse_overtake_page(page_url, source):
    if urlparse(page_url).hostname != "overtakefans.com":
        raise ValueError("unexpected OvertakeFans page host")
    for match in IFRAME_RE.finditer(source):
        embed_url = urljoin(page_url, html.unescape(match.group(1)))
        parsed = urlparse(embed_url)
        if parsed.scheme == "https" and parsed.hostname == "hakunamatata5.org":
            return embed_url
    raise ValueError("OvertakeFans page has no approved player")


def parse_overtake_player(embed_url, source):
    parsed_embed = urlparse(embed_url)
    if parsed_embed.scheme != "https" or parsed_embed.hostname != "hakunamatata5.org":
        raise ValueError("unexpected OvertakeFans player host")
    match = CLAPPR_RE.search(source)
    if not match:
        raise ValueError("OvertakeFans player has no HLS source")
    address = urljoin(embed_url, html.unescape(match.group(1)).replace("\\/", "/"))
    parsed_address = urlparse(address)
    if (
        parsed_address.scheme != "https"
        or parsed_address.hostname != parsed_embed.hostname
        or not parsed_address.path.lower().endswith(".m3u8")
    ):
        raise ValueError("OvertakeFans player returned an invalid HLS source")
    return {
        "type": "hls",
        "address": address,
        "headers": {
            "Origin": "https://hakunamatata5.org",
            "Referer": embed_url,
            "User-Agent": USER_AGENT,
        },
    }


def resolve_overtake(page_url):
    page_request = Request(page_url, headers={"User-Agent": USER_AGENT})
    with urlopen(page_request, timeout=20) as response:
        embed_url = parse_overtake_page(
            page_url, response.read().decode("utf-8", "replace")
        )
    player_request = Request(
        embed_url, headers={"User-Agent": USER_AGENT, "Referer": page_url}
    )
    with urlopen(player_request, timeout=20) as response:
        return parse_overtake_player(
            embed_url, response.read().decode("utf-8", "replace")
        )


if __name__ == "__main__":
    fixture = '<iframe src="https://media.example/race/master.m3u8?token=a&amp;b=2"></iframe>'
    result = parse_nontonx("https://replay.nontonx.com/2026/race.html", fixture)
    assert result["address"] == "https://media.example/race/master.m3u8?token=a&b=2"
    try:
        parse_nontonx("https://example.com/race.html", fixture)
    except ValueError:
        pass
    else:
        raise AssertionError("host validation failed")
    embed = parse_overtake_page(
        "https://overtakefans.com/f1-race-archive/watch/index.php?race=test",
        '<iframe src="https://hakunamatata5.org/lewis/test.html"></iframe>',
    )
    assert embed == "https://hakunamatata5.org/lewis/test.html"
    overtake = parse_overtake_player(
        embed,
        "new Clappr.Player({source: 'media/race.m3u8', parentId: '#player'});",
    )
    assert overtake["address"] == "https://hakunamatata5.org/lewis/media/race.m3u8"
    live = parse_nonton_live(
        "https://esp32.nontonx.com/formulaplayer1",
        "//const array = ['https://old.example/old.m3u8'];\n"
        "const array = ['https://live.example/live.m3u8'];",
    )
    assert live == ["https://live.example/live.m3u8"]
    aces = parse_aces_live(
        "https://acestrlms.pages.dev/r4lly/",
        '<!-- https://old.example/old.m3u8 --><iframe src="/jw?s=https://live.example/live.m3u8">',
    )
    assert aces == ["https://live.example/live.m3u8"]
    pit = parse_pitsport_live(
        "https://pitsport.live/watch/00000000-0000-0000-0000-000000000000",
        '{"success":true,"content":[{"iframe":"https://player.example/?s=https://live.example/live.m3u8"}]}',
    )
    assert pit == ["https://live.example/live.m3u8"]
    print("Page playback parser self-test passed.")

import json
import os
import time
import xml.etree.ElementTree as ET
from urllib.parse import urljoin, urlparse

import requests
import xbmc
import xbmcaddon
import xbmcvfs


ADDON = xbmcaddon.Addon("plugin.video.torquelite")
ADDON_PATH = ADDON.getAddonInfo("path")
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
BUNDLED_PATH = os.path.join(ADDON_PATH, "xml", "replay-metadata.json")
CACHE_PATH = os.path.join(PROFILE_PATH, "replay-catalog-cache.json")
VALID_STATES = ("scheduled", "live", "completed", "replay_available", "unavailable")


def _read_json(path):
    source = xbmcvfs.File(path)
    try:
        return json.loads(source.read())
    finally:
        source.close()


def _validate(catalog):
    if catalog.get("schema_version") != 1 or not catalog.get("generated_at"):
        raise ValueError("unsupported replay catalog schema")
    items = catalog.get("items")
    if not isinstance(items, list):
        raise ValueError("replay catalog has no items list")
    for item in items:
        if not all(key in item for key in ("provider", "series", "title", "event_year", "page_url", "state")):
            raise ValueError("replay catalog item is incomplete")
        if item["state"] not in VALID_STATES:
            raise ValueError("replay catalog item has an invalid state")
        parsed = urlparse(item["page_url"])
        if parsed.scheme not in ("http", "https") or not parsed.netloc:
            raise ValueError("replay catalog contains an invalid page URL")
        playback = item.get("playback")
        if playback:
            address = urlparse(playback.get("address", ""))
            if address.scheme != "https" or not address.netloc:
                raise ValueError("replay catalog playback URLs must use HTTPS")
            if playback.get("type") not in ("direct", "hls", "dash"):
                raise ValueError("replay catalog playback type is unsupported")
            headers = playback.get("headers", {})
            if not isinstance(headers, dict) or not all(
                isinstance(key, str) and isinstance(value, str) for key, value in headers.items()
            ):
                raise ValueError("replay catalog playback headers are invalid")
    return catalog


def _repository_catalog_url():
    override = ADDON.getSetting("maintained_catalog_url").strip()
    if override:
        return override
    try:
        repo_path = xbmcaddon.Addon("repository.familytorque").getAddonInfo("path")
        manifest = xbmcvfs.File(os.path.join(repo_path, "addon.xml"))
        try:
            root = ET.fromstring(manifest.read())
        finally:
            manifest.close()
        datadir = root.findtext("./extension/dir/datadir", "").strip()
        return urljoin(datadir.rstrip("/") + "/", "catalog/replay-metadata.json")
    except Exception as exc:
        xbmc.log("Torque Lite catalog endpoint unavailable: {}".format(exc), xbmc.LOGWARNING)
        return ""


def _safe_endpoint(url):
    parsed = urlparse(url)
    if parsed.scheme == "https":
        return True
    return parsed.scheme == "http" and parsed.hostname in ("127.0.0.1", "localhost", "::1")


def _cached():
    if not xbmcvfs.exists(CACHE_PATH):
        return None
    envelope = _read_json(CACHE_PATH)
    return {"fetched_at": float(envelope["fetched_at"]), "catalog": _validate(envelope["catalog"])}


def _write_cache(catalog):
    xbmcvfs.mkdirs(PROFILE_PATH)
    temporary = CACHE_PATH + ".tmp"
    target = xbmcvfs.File(temporary, "w")
    try:
        target.write(json.dumps({"fetched_at": time.time(), "catalog": catalog}))
    finally:
        target.close()
    if xbmcvfs.exists(CACHE_PATH):
        xbmcvfs.delete(CACHE_PATH)
    if not xbmcvfs.rename(temporary, CACHE_PATH):
        raise OSError("could not replace replay catalog cache")


def refresh(force=False):
    cached = None
    try:
        cached = _cached()
    except Exception as exc:
        xbmc.log("Torque Lite ignored invalid replay cache: {}".format(exc), xbmc.LOGWARNING)

    refresh_minutes = max(5, int(ADDON.getSetting("maintained_catalog_refresh") or 15))
    if cached and not force and time.time() - cached["fetched_at"] < refresh_minutes * 60:
        return cached["catalog"]

    endpoint = _repository_catalog_url()
    if endpoint and _safe_endpoint(endpoint):
        try:
            response = requests.get(endpoint, timeout=20)
            response.raise_for_status()
            catalog = _validate(response.json())
            _write_cache(catalog)
            xbmc.log("Torque Lite refreshed maintained replay catalog", xbmc.LOGINFO)
            return catalog
        except Exception as exc:
            xbmc.log("Torque Lite replay catalog refresh failed: {}".format(exc), xbmc.LOGWARNING)
    elif endpoint:
        xbmc.log("Torque Lite rejected non-HTTPS catalog endpoint: {}".format(endpoint), xbmc.LOGWARNING)

    if cached:
        return cached["catalog"]
    return _validate(_read_json(BUNDLED_PATH))


def load_catalog():
    return refresh(force=False)

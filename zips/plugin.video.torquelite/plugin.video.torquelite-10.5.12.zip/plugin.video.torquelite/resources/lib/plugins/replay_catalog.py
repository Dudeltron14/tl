import json
import urllib.parse
from datetime import datetime

import xbmc
import xbmcgui

from ..catalog_store import load_catalog
from ..catalog_visibility import (
    format_local_event_time,
    live_items,
    motorsport_names,
    replay_items,
    search_items,
    slug,
    today_items,
)
from ..page_playback import (
    resolve_aces_live,
    resolve_nonton_live,
    resolve_nontonx,
    resolve_overtake,
    resolve_pitsport_live,
)
from ..plugin import Plugin, run_hook


class replay_catalog(Plugin):
    name = "maintained replay catalog"
    priority = 150

    def _items(self):
        return load_catalog().get("items", [])

    def _live_items(self):
        return live_items(self._items())

    def _replay_items(self):
        return replay_items(self._items())

    def _for_motorsport(self, items, sport):
        return [item for item in items if slug(item["series"]) == sport]

    def _display(self, items):
        processed = [run_hook("process_item", item) for item in items]
        processed = [run_hook("get_metadata", item, return_item_on_failure=True) for item in processed]
        run_hook("display_list", processed)

    def _catalog_item(self, item):
        status = item.get("state", "unavailable").replace("_", " ").title()
        date = item.get("event_date_label") or item.get("event_date", "")
        local = format_local_event_time(item)
        if local:
            details = "{} — {} — Source page: {}".format(local, status, item["page_url"])
        else:
            details = "{}. {}. Source page: {}".format(status, date, item["page_url"])
        title = item["title"]
        if item.get("state") == "live":
            title = "[COLOR red][LIVE][/COLOR] " + title
        elif item.get("state") == "scheduled":
            title = "[COLOR gold][Scheduled][/COLOR] " + title
        elif item.get("state") == "unavailable":
            title = "[COLOR gray][Unavailable][/COLOR] " + title
        result = {
            "type": "item",
            "title": title,
            "summary": details,
            "link": "message/{} catalog metadata. Source URL is shown in item information.".format(status),
        }
        if item.get("thumbnail"):
            result["thumbnail"] = item["thumbnail"]
        if item.get("playback") and item.get("state") in ("live", "replay_available"):
            result["link"] = item["playback"]["address"]
            result["catalog_playback"] = item["playback"]
        elif (
            item.get("state") == "replay_available"
            and item.get("provider") in ("FullRaces", "NontonX", "OvertakeFans")
        ) or item.get("provider") == "NontonX Live" or (
            item.get("state") == "live"
            and item.get("provider") in ("Aces Live", "PitSport Live")
        ):
            result["link"] = item["page_url"]
            result["catalog_page_playback"] = {
                "provider": item["provider"],
                "address": item["page_url"],
            }
        return result

    def _today_catalog_item(self, item):
        result = self._catalog_item(item)
        title = result["title"]
        if item.get("event_time"):
            try:
                start = datetime.fromisoformat(
                    item["event_time"].replace("Z", "+00:00")
                ).astimezone()
                title = "[{}] {}".format(start.strftime("%I:%M %p").lstrip("0"), title)
            except ValueError:
                pass
        result["title"] = "{} [COLOR gray]({})[/COLOR]".format(
            title, item["provider"]
        )
        return result

    def play_video(self, payload):
        item = json.loads(payload)
        playback = item.get("catalog_playback")
        page_playback = item.get("catalog_page_playback")
        if not playback and not page_playback:
            return False
        if page_playback:
            if page_playback["provider"] == "FullRaces":
                return run_hook(
                    "play_video",
                    json.dumps(
                        {
                            "title": item.get("title", "Replay"),
                            "thumbnail": item.get("thumbnail", ""),
                            "sportjetextractors": {
                                "address": page_playback["address"],
                                "links": True,
                            },
                        }
                    ),
                )
            try:
                resolver = {
                    "Aces Live": resolve_aces_live,
                    "NontonX Live": resolve_nonton_live,
                    "OvertakeFans": resolve_overtake,
                    "PitSport Live": resolve_pitsport_live,
                    "NontonX": resolve_nontonx,
                }[page_playback["provider"]]
                playback = resolver(page_playback["address"])
            except Exception as exc:
                xbmc.log("Torque Lite page playback failed: {}".format(exc), xbmc.LOGWARNING)
                xbmcgui.Dialog().notification(
                    "Playback failed", str(exc), xbmcgui.NOTIFICATION_ERROR, 5000
                )
                return True
        address = playback["address"]
        media_type = playback["type"]
        list_item = xbmcgui.ListItem(item.get("title", "Replay"), path=address)
        list_item.setInfo("video", {"title": item.get("title", "Replay"), "plot": item.get("summary", "")})
        headers = playback.get("headers", {})
        if headers:
            address += "|" + urllib.parse.urlencode(headers)
            list_item.setPath(address)
        if media_type == "hls":
            list_item.setProperty("inputstream", "inputstream.ffmpegdirect")
            list_item.setProperty("inputstream.ffmpegdirect.manifest_type", "hls")
            list_item.setMimeType("application/vnd.apple.mpegurl")
        elif media_type == "dash":
            list_item.setProperty("inputstream", "inputstream.adaptive")
            list_item.setProperty("inputstream.adaptive.manifest_type", "mpd")
            list_item.setMimeType("application/dash+xml")
        xbmc.Player().play(address, list_item)
        return True

    def routes(self, plugin):
        @plugin.route("/catalog/today")
        def today_schedule():
            self._display(
                [self._today_catalog_item(item) for item in today_items(self._items())]
            )

        @plugin.route("/motorsports")
        def motorsports():
            self._display(
                [
                    {
                        "type": "dir",
                        "title": name,
                        "link": "route://motorsports/{}".format(slug(name)),
                    }
                    for name in motorsport_names(self._items())
                ]
            )

        @plugin.route("/motorsports/<sport>")
        def motorsport(sport):
            live = self._for_motorsport(self._live_items(), sport)
            replays = self._for_motorsport(self._replay_items(), sport)
            items = []
            if live:
                items.append(
                    {
                        "type": "dir",
                        "title": "Live & Upcoming ({})".format(len(live)),
                        "link": "route://motorsports/{}/live".format(sport),
                    }
                )
            if replays:
                items.append(
                    {
                        "type": "dir",
                        "title": "Replays ({})".format(len(replays)),
                        "link": "route://motorsports/{}/replays".format(sport),
                    }
                )
            self._display(items)

        @plugin.route("/motorsports/<sport>/live")
        def motorsport_live(sport):
            items = self._for_motorsport(self._live_items(), sport)
            items.sort(key=lambda item: item.get("event_time") or item.get("event_date", ""))
            self._display([self._catalog_item(item) for item in items])

        @plugin.route("/motorsports/<sport>/replays")
        def motorsport_replay_years(sport):
            matches = self._for_motorsport(self._replay_items(), sport)
            years = sorted({item["event_year"] for item in matches}, reverse=True)
            self._display(
                [
                    {
                        "type": "dir",
                        "title": str(year),
                        "link": "route://motorsports/{}/replays/{}".format(sport, year),
                    }
                    for year in years
                ]
            )

        @plugin.route("/motorsports/<sport>/replays/<year>")
        def motorsport_replay_providers(sport, year):
            matches = [
                item
                for item in self._for_motorsport(self._replay_items(), sport)
                if str(item["event_year"]) == year
            ]
            providers = sorted({item["provider"] for item in matches})
            self._display(
                [
                    {
                        "type": "dir",
                        "title": provider,
                        "link": "route://motorsports/{}/replays/{}/{}".format(
                            sport, year, slug(provider)
                        ),
                    }
                    for provider in providers
                ]
            )

        @plugin.route("/motorsports/<sport>/replays/<year>/<provider>")
        def motorsport_replay_entries(sport, year, provider):
            matches = [
                item
                for item in self._for_motorsport(self._replay_items(), sport)
                if str(item["event_year"]) == year and slug(item["provider"]) == provider
            ]
            matches.sort(
                key=lambda item: item.get("event_time") or item.get("event_date", ""),
                reverse=True,
            )
            self._display([self._catalog_item(item) for item in matches])

        def show_search(query):
            matches = search_items(self._items(), query)
            if not matches:
                xbmcgui.Dialog().notification(
                    "Search", "No matching events", xbmcgui.NOTIFICATION_INFO, 3000
                )
            self._display([self._catalog_item(item) for item in matches])

        @plugin.route("/catalog/search")
        def catalog_search():
            query = xbmcgui.Dialog().input("Search motorsport catalog")
            show_search(query)

        @plugin.route("/catalog/search/<path:query>")
        def catalog_search_query(query):
            show_search(urllib.parse.unquote_plus(query))

        @plugin.route("/replays")
        def years():
            years = sorted({item["event_year"] for item in self._replay_items()}, reverse=True)
            self._display(
                [
                    {"type": "dir", "title": str(year), "link": f"route://replays/{year}"}
                    for year in years
                ]
            )

        @plugin.route("/replays/schedule")
        def schedule():
            items = self._live_items()
            items.sort(key=lambda item: item.get("event_time") or item.get("event_date", ""))
            self._display([self._catalog_item(item) for item in items])

        @plugin.route("/replays/<year>")
        def providers(year):
            names = sorted(
                {
                    item["provider"]
                    for item in self._replay_items()
                    if str(item["event_year"]) == year
                }
            )
            self._display(
                [
                    {
                        "type": "dir",
                        "title": name,
                        "link": f"route://replays/{year}/{slug(name)}",
                    }
                    for name in names
                ]
            )

        @plugin.route("/replays/<year>/<provider>")
        def series(year, provider):
            matches = [
                item
                for item in self._replay_items()
                if str(item["event_year"]) == year and slug(item["provider"]) == provider
            ]
            names = sorted({item["series"] for item in matches})
            self._display(
                [
                    {
                        "type": "dir",
                        "title": name,
                        "link": f"route://replays/{year}/{provider}/{slug(name)}",
                    }
                    for name in names
                ]
            )

        @plugin.route("/replays/<year>/<provider>/<series>")
        def entries(year, provider, series):
            matches = [
                item
                for item in self._replay_items()
                if str(item["event_year"]) == year
                and slug(item["provider"]) == provider
                and slug(item["series"]) == series
            ]
            items = []
            for item in matches:
                items.append(self._catalog_item(item))
            self._display(items)

import re
from datetime import datetime


def format_local_event_time(item):
    """Return a subtitle string with the event start converted to the Kodi
    device's local timezone, or '' when the item has no usable event_time."""
    event_time = item.get("event_time")
    if not event_time:
        return ""
    try:
        start = datetime.fromisoformat(event_time.replace("Z", "+00:00"))
    except ValueError:
        return ""
    if start.tzinfo is None:
        start = start.astimezone()
    local = start.astimezone()
    # Kodi-safe simple format; show date + time (strip leading zero on hour).
    return local.strftime("%b %d, %I:%M %p").lstrip("0").replace(" 0", " ")


LIVE_PROVIDERS = {"Aces Live", "NontonX Live", "PitSport Live"}
REPLAY_PROVIDERS = {"FullRaces", "NontonX", "OvertakeFans"}


def live_items(items):
    return [
        item
        for item in items
        if item.get("provider") in LIVE_PROVIDERS
        and item.get("state") in ("live", "scheduled")
    ]


def replay_items(items):
    return [
        item
        for item in items
        if item.get("provider") in REPLAY_PROVIDERS
        and item.get("state") == "replay_available"
    ]


def today_items(items, now=None):
    now = now or datetime.now().astimezone()
    today = now.date()
    matches = []
    for item in live_items(items):
        if item.get("state") == "live":
            matches.append(item)
            continue
        event_time = item.get("event_time")
        if event_time:
            try:
                start = datetime.fromisoformat(event_time.replace("Z", "+00:00"))
                if start.tzinfo is None:
                    start = start.astimezone()
                if start.astimezone(now.tzinfo).date() == today:
                    matches.append(item)
                continue
            except ValueError:
                pass
        if item.get("event_date") == today.isoformat():
            matches.append(item)
    return sorted(matches, key=lambda item: item.get("event_time") or "")


def slug(value):
    return re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")


def visible_items(items):
    return live_items(items) + replay_items(items)


def motorsport_names(items):
    return sorted({item["series"] for item in visible_items(items)})


def search_items(items, query, limit=200):
    terms = query.casefold().split()
    if not terms:
        return []
    matches = []
    for item in visible_items(items):
        text = " ".join(
            str(item.get(key, ""))
            for key in ("title", "series", "provider", "event_date", "event_date_label")
        ).casefold()
        if all(term in text for term in terms):
            matches.append(item)
    matches.sort(key=lambda item: item.get("event_time") or item.get("event_date", ""), reverse=True)
    matches.sort(key=lambda item: {"live": 0, "scheduled": 1}.get(item.get("state"), 2))
    return matches[:limit]
